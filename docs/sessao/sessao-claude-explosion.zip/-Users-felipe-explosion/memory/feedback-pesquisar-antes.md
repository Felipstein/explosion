---
name: feedback-pesquisar-antes
description: "Antes de mudar algo visual/físico, pesquisar como AAA/literatura fazem, planejar e comunicar o plano — nada de chutar valores"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 7fab7fca-b804-45c4-8302-972a750d5b27
  modified: 2026-10-02T19:56:10.536Z
---

Toda mudança de aparência (iluminação, noite, exposição, materiais) começa
com pesquisa: como jogos AAA e a literatura (GDC, SIGGRAPH, papers) resolvem.
Depois um plano curto, comunicado ao usuário, e só então implementação.

**Why:** "TUDO AQUI TEM QUE SER BEM ESTUDADO PLANEJADO COMUNICADO" — ele
interrompeu quando comecei a ajustar a noite chutando constantes (luar ×27,
exposição) sem referência.

**How to apply:** pesquisar (WebSearch/WebFetch), citar as fontes no plano,
mostrar o que será feito e por quê. Desde 03/10 ele não quer mais ser
consultado a cada passo: o plano vai junto do resultado, sem esperar o ok
(ver [[feedback-nao-pedir-confirmacao]]). Medir o problema antes é ok. Ver
[[feedback-commit-so-com-aprovacao]] e [[explosion-project]].
