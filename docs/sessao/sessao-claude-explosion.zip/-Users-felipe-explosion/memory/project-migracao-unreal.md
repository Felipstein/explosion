---
name: project-migracao-unreal
description: "Migração pra Unreal DECIDIDA em 03/10/2026; WebGL congelado na tag v6-fumaca-interacao como referência"
metadata:
  node_type: memory
  type: project
  originSessionId: 7fab7fca-b804-45c4-8302-972a750d5b27
  modified: 2026-10-02T21:23:38.042Z
---

Em 02/10/2026 o Felipe disse que vão migrar pra Unreal Engine "jaja", e que
lá vou ter muito mais poder (inclusive computacional) pra melhorar coisas como
sombras de muitas luzes. Até lá: "vamos continuar fazendo a nossa base".

**Why:** o WebGL2 tem tetos (16 unidades de textura, sem ray tracing, custo
por luz com sombra) que a Unreal resolve (Virtual Shadow Maps, MegaLights,
Heterogeneous Volumes).

**How to apply:** não investir em engenharia de escala específica do WebGL
(ex.: atlas de sombras, sombras em espaço de tela pra dezenas de luzes) —
quando surgir, anotar como "na Unreal". Priorizar o que forma a base visual e
o conhecimento que transfere (física, calibração, aparência, bake com vetores
de movimento). Ver [[explosion-project]].

**03/10/2026 — decidido migrar.** O usuário concordou depois que a troca
gravação → grade da fumaça continuou perceptível (brilho muda, subida
desacelera de repente). WebGL congelado no commit 211eb76, tag
`v6-fumaca-interacao` ("referência final"). Próximos passos combinados:
documento de migração (sistema → equivalente na Unreal, números, vídeos
de referência em `captures/`) e projeto Unreal com captura automática
(Python + render por linha de comando), porque lá eu não tenho o painel do
navegador pra testar quadro a quadro sozinho.
