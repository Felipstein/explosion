---
name: feedback-commit-so-com-aprovacao
description: "No projeto da explosão, só commitar depois que o usuário testar e disser \"aprovado\""
metadata:
  node_type: memory
  type: feedback
  originSessionId: 7fab7fca-b804-45c4-8302-972a750d5b27
  modified: 2026-10-02T19:10:25.350Z
---

Não commitar mudanças até o usuário testar e aprovar explicitamente.

**Why:** ele quer TESTAR cada melhoria antes de virar versão salva ("não
commita sem eu falar que está aprovado"). Commit = versão aprovada por ele.

**How to apply:** implementar, testar eu mesmo, reportar e esperar o
"aprovado". Uma melhoria por vez (ele pediu "só o 1 primeiro"). Ver
[[explosion-project]].
