---
name: feedback-jogabilidade-primeiro
description: Realismo físico não basta — pesar a leitura do jogo (câmera de RTS vista de cima) antes de decidir duração/cobertura de efeitos
metadata:
  node_type: memory
  type: feedback
  originSessionId: 7fab7fca-b804-45c4-8302-972a750d5b27
  modified: 2026-10-03T23:21:46.785Z
---

Em 03/10/2026 o Felipe criticou a fumaça que fica minutos no campo (4b): "não
passou na sua cabeça de estudo que isso atrapalha muito a jogatina?". Eu
tinha calibrado só pela física (dispersão Pasquill–Gifford, decaimento de
70 s) e esqueci que a câmera do RTS olha de cima e a nuvem a ~36 m fica
entre a câmera e as unidades.

**Why:** é um jogo (RTS estilo C&C); efeito que esconde unidades ou poluí a
leitura da batalha é defeito, por mais físico que seja.

**How to apply:** em todo efeito novo, junto do estudo de física/AAA,
perguntar: quanto tempo dura, quanto da tela cobre, esconde unidades?
Referência de gênero: efeitos decorativos somem rápido; fumaça persistente
só como mecânica deliberada (cortina de fumaça do Company of Heroes).
Ver [[explosion-project]], [[feedback-pesquisar-antes]].
