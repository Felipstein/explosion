---
name: explosion-project
description: Projeto /Users/felipe/explosion — explosão volumétrica AAA em WebGL2 puro, iniciado 19/08/2026
metadata:
  type: project
---

Felipe pediu uma explosão volumétrica "AAA, linda, realista, volumosa, tudo
projetando sombra", com ênfase explícita em algoritmos de mercado bem
estudados e estruturados — não MVP, não chute.

Escolha de stack: **WebGL2 puro, zero dependências**. Ele ofereceu Three.js
mid-turn; recusei com justificativa (o núcleo é solver de fluido em atlas 3D +
raymarch em half-res + cadeia de post própria; no Three.js o custo seria
brigar com o render loop e o acesso ao depth buffer). Ele aceitou.

Estado detalhado, breakdown de performance e próximos passos em
`STATUS.md` na raiz do projeto — ler primeiro ao retomar. Arquitetura e
referências acadêmicas em `ARCHITECTURE.md`.

**Why:** trabalho em andamento, pausado a pedido dele em 19/08/2026 com dois
problemas abertos (performance a 7fps e escala física do evento).

**How to apply:** ao retomar, ler `STATUS.md` antes de mexer no código. Ele
valoriza medição em cima de palpite — o projeto tem `__app.prof.totals()`
com timer queries de GPU e `__app.bench()` justamente pra isso.

**Atualização 01/10/2026:** adicionado sistema completo de hora do dia
(`js/atmosphere.js` + `js/celestial.js`) com modelo atmosférico de Hillaire
2020 em LUTs. Também resolvida a escala física do evento que estava no
STATUS. Pendências principais: performance (~11 fps a 128³ em 1080p) e
partículas/SSAO nunca construídos.

Nota de ambiente: o preview do app serve os módulos ES de um cache agressivo;
`devserver.py` manda `no-store`, mas um reload simples ainda pode reusar
módulos já carregados — forçar com `fetch(url,{cache:'reload'})` em cada
módulo e depois trocar a URL.

**Performance (01/10/2026):** 31 → 22 ms/frame no preset `alta`. Presets
medidos: baixa 7ms/142fps, media 14ms/71fps, alta 22ms/46fps.

Armadilha de medição que custou várias tentativas e NÃO deve se repetir:
- Timer queries de GPU (`EXT_disjoint_timer_query_webgl2`) mentem neste
  runtime — apontaram `post` (36ms) e `luzFogo` (26ms) como gargalos; ambos
  custam ~0. Medem drenagem de fila, não trabalho.
- `gl.finish()` é no-op; `clientWaitSync` não bloqueia no Chrome;
  `readPixels` de um FBO auxiliar não sincroniza o resto do frame.
- O que funciona: `readPixels` de 1 pixel do framebuffer PADRÃO. É a base de
  `App.ablate()`, que desliga um estágio por vez em round-robin.
- O rAF marca ~250ms/frame quando o painel de preview está oculto. Isso é
  throttling do navegador, não custo de render — não confundir os dois.

**Realismo da explosão (01/10/2026):** a causa de a explosão não convencer
era o modelo de combustão — queimava onde estava QUENTE em vez de onde o
combustível tinha MISTURADO com ar, então a bola inteira acendia de uma vez
sem frente de chama. Reescrito pra combustão limitada por mistura, fuligem
com formação rica/oxidação pobre, detonação como fonte de pressão,
turbulência na interface de densidade e estrutura na condição inicial.

Ferramentas criadas e que devem ser usadas antes de chutar parâmetros:
`__capture()` (folha de contato temporal, câmera travada) e `__fields()`
(mesmo instante, vários campos). Gravam via POST pro devserver.py, o que
funciona mesmo com a janela do app minimizada — o screenshot do browser pane
falha nesse caso.

**Qualidade de imagem (01/10, rev.4):** a queixa "parece 2012 / parece PNG"
eram quatro bugs de RENDER, nenhum no simulador: (1) textura assada sem
mipmap + ruído procedural sem LOD → tempestade de aliasing; (2) bump por
diferenças finitas com fator não-adimensional (divide por e=0.03, então 0.30
vira ~0.9) → normais aleatórias; (3) poeira absorvendo sem receber luz do
fogo → halo preto na silhueta (faltava tauCap no canal de fogo do volume de
luz); (4) sootOxid consumindo quase toda a fuligem.

Lição recorrente neste projeto: atenuação por LOD aplicada com `if` sobre
valor contínuo gera o mesmo salpicado que se quer evitar — tem que ser
multiplicação suave.

**Contexto de uso (01/10):** o alvo é um RTS clássico — só o lado visual, sem
lógica de jogo. Vai precisar de múltiplos tipos de explosão com magnitudes
diferentes (ainda não feito).

**Bug da sombra fantasma:** render e sombra usavam densidades diferentes
(`sampleMedium` erodia, `volumeShadow` não). Corrigido com `effExtinction()`
compartilhada + corte duro de resíduo no solver. Regra pra lembrar: efeito
aplicado só no render diverge do que o resto do pipeline acredita existir.

**HUD (01/10):** sidebar estilo C&C em index.html, clique no terreno detona.
Exigiu tornar o domínio da simulação móvel (`uDomainOrigin` em COMMON, era
`#define` fixo na origem). O thumbnail do armamento é um render do próprio
motor — receita no STATUS.md.

**Regra de câmera:** NÃO acompanhar a detonação. É um RTS; a câmera fica onde
o jogador deixou.

**Pool de explosões (01/10):** `js/blastpool.js` — N simulações simultâneas,
slots com mesma resolução/domínio e origens diferentes. Composição
front-to-back com `blendFuncSeparate(DST_ALPHA, ONE, ZERO, SRC_ALPHA)`.
Jovens avançam todo frame, velhas em rodízio: 3 explosões custam 1.7× uma.

Armadilha de GLSL deste driver: array de sampler exige índice CONSTANTE —
índice de laço não serve. Desenrolar em JS na montagem do shader.

**Escalabilidade (01/10):** arquitetura final = o solver é BAKER, o runtime
instancia (`js/bake.js` + `js/instances.js`). 96 instâncias a 5.6ms. As três
chaves: scissor por instância, empty-space skipping por macro assado (11ms →
0.24ms por instância) e LOD por área em tela. Memória: 64MB (64³ × 64 quadros,
amostragem temporal não-uniforme, densidade em gamma).

**Camada final (01/10):** 3 variantes assadas + 5 magnitudes com leis de
escala (W^1/3 em comprimento E tempo) + sombra volumétrica das instâncias +
HUD com thumbnails renderizados pelo motor.

Bug que vale lembrar: luz pontual no centro da bola de fogo sendo ocluída
pelo próprio volume. Com vários oclusores empilhando o teto de transmitância,
o resultado vai a zero. Luzes e oclusores precisam de identidade pra pular
auto-oclusão.

**Sessão de uso real (02/10):** o usuário testa CLICANDO no app, não via
console. Bugs que só apareciam assim: câmera `cine` olhando pro céu com o
tempo global, clique perto do horizonte jogando a explosão a 1e12 m, dt
negativo explodindo o shake. Antes de dizer "pronto", reproduzir com cliques
reais + loop rAF real (browser_batch com left_click), não só frameStep síncrono.

**Bake = asset (02/10):** `assets/bake/<hash>.bin` gerado pelo próprio app
(POST /asset no devserver). Mudou fluid/glsl/volume/bake/volumeRender/blackbody
→ hash muda → próxima carga re-assa (~18 s visível, incremental) e regrava.
Depois de mexer no solver, abrir a página uma vez pra regenerar o asset antes
de entregar. Meu painel do navegador costuma ficar `visibilityState: hidden`
(rAF parado): medir FPS/timings ali é inválido; renderizar manualmente com
frameStep + toBlob → /save e ler o PNG.

**Referência visual = explosão ao vivo (tecla espaço) (02/10):** o usuário
compara o clique com ela. Bake usa o MESMO passo (1/60) e semente 4242 na
variante 0, então dá pra comparar render puro lado a lado. Pra comparar:
`app.hold=true`, `vol.syncFireLight(slot)` a cada frame da ao vivo (a luz
assíncrona fica velha num laço sem vsync) e render imediatamente antes do
toBlob (ceder ao navegador limpa o buffer).

**Configuração gráfica (02/10):** `js/settings.js` (esquema+presets+localStorage)
→ `App.applySettings`. Usuário quer foco forte em performance + qualidade +
customização (vai virar RTS). Opção nova = entrada no SCHEMA + valor nos 4
presets + leitura em `_applyLiveSettings`. Medir custo com ablação INTERCALADA
(A/B alternado, mediana): no painel oculto a GPU oscila ±5 ms.

**02/10/2026 noite:** item 2 (sombras da luz do fogo: cubos + PCSS + filtro
bilateral em tela) e a noite estilo Ghost of Tsushima (céu de luar, exposição
por iluminância física, Purkinje calibrado nos slides do Patry, adaptação que
mede superfícies) aprovados e commitados (tag v4-noite-sombras).
**03/10/2026:** item 3 (vetores de movimento no bake) aprovado e commitado
(tag v5-vetores-movimento). Item 4: o vento (4a) foi rejeitado e desfeito
("parece só empurrado pro lado"); seguir com 4b fumaça que fica + 4c
interação com avião/míssil/tiro/explosão.
O usuário não conhece os números de resolução do bake (48/64/80/96): falar
pelos nomes da gaveta "Detalhe das explosões" (baixo/médio/alto/ultra).
Harness de teste quadro a quadro: `captures/_harness.js` (import no console).
**03/10 (tarde):** 4b+4c construídos e NÃO commitados (aguardando o
"aprovado"): `js/battlesmoke.js` (grade de velocidade 2 m + fumaça 1 m,
MUSCL conservativo, entrega 3.2–3.5 s, ~5 ms) e `js/movers.js` (avião /
míssil / disparo, teclas a/m/d). Lições: testar efeitos com A/B de história
idêntica (zerar `battle.time` após `__fresh`); erosão absoluta apaga fumaça
diluída; perturbador que SOBRESCREVE a velocidade mata a subida da pluma —
somar, uma vez por ponto. Rev. 2 (03/10 noite): fumaça some em ~15 s
(jogabilidade), e o "ar duro" foi medido (vórtice de asa perdia metade em
0.7 s) e corrigido — pluma em canal próprio, MacCormack + confinement,
jato limitado pelo empuxo. Ver em MOVIMENTO (vídeo via MediaRecorder →
/save, ffmpeg pra folha), não em fotos: foto escondeu a dureza.
O painel do navegador é COMPARTILHADO com o usuário: depois de testar com o
harness (`app.hold=true`, câmera fixa, `hide-ui`), recarregar a página — ele
abriu o painel e achou o app "travado".
Pendências vistas: aliasing de normal nos pilares, crepúsculo saturado (falta
white balance por hora). Ver [[feedback-commit-so-com-aprovacao]].
