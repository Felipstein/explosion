---
name: feedback-poucas-configuracoes
description: Configuração voltada ao jogador deve ser só presets (baixa/média/alta/ultra) + poucas opções; o painel detalhado é ferramenta de debug
metadata:
  node_type: memory
  type: feedback
  originSessionId: 7fab7fca-b804-45c4-8302-972a750d5b27
  modified: 2026-10-02T17:28:53.770Z
---

Pro jogador, basta o preset pronto (baixa/média/alta/ultra) e poucas opções.
A gaveta "⚙ personalizar" com 18 opções fica, mas como ferramenta de DEBUG.

**Why:** "em todo jogo ninguém quase entende nada" — jogos reais expõem poucas
configurações; excesso confunde o jogador.

**How to apply:** opção nova de qualidade entra nos presets por padrão; só vai
pra UI do jogador se for algo que jogador entende (ex.: brilho, resolução).
Não expandir a gaveta como se fosse a UI final. Ver [[explosion-project]].
